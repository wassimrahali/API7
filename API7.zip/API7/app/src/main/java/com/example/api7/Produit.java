package com.example.api7;

public class Produit {

    private String name;

    public Produit(String name) {
        this.name = name;
    }

    public String getNomProduit() {
        return name;
    }
}
